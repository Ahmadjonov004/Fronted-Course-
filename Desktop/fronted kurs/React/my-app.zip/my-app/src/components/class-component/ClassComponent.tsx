import React, { Component } from 'react'

class ClassComponent extends Component{
    render(){
        return <h1>Asilbek</h1>
    }
}
export default ClassComponent;
