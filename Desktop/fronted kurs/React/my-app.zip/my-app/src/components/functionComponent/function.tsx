
import React from "react";

function FunctionComponent() {
  return <h1>Hammasi yaxshi boladi</h1>;
}

export default FunctionComponent;
